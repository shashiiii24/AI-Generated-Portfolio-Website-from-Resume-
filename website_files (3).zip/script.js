document.addEventListener('DOMContentLoaded', () => {
    const themeToggleCheckbox = document.getElementById('theme-toggle-checkbox');
    const htmlElement = document.documentElement;
    const storedTheme = localStorage.getItem('theme');

    // Apply stored theme on initial load
    if (storedTheme) {
        htmlElement.setAttribute('data-theme', storedTheme);
        if (storedTheme === 'dark') {
            themeToggleCheckbox.checked = true;
        }
    }

    // Theme toggle functionality
    themeToggleCheckbox.addEventListener('change', () => {
        if (themeToggleCheckbox.checked) {
            htmlElement.setAttribute('data-theme', 'dark');
            localStorage.setItem('theme', 'dark');
        } else {
            htmlElement.removeAttribute('data-theme');
            localStorage.removeItem('theme');
        }
    });

    // Smooth scrolling for navigation links
    document.querySelectorAll('#navbar .nav-menu a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();

            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
});